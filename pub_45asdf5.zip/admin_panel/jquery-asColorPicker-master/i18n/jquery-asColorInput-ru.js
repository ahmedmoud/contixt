// asColorPicker
// Russian (ru) localization

(function($) {
    var localization = $.asColorPicker.localization["ru"] = {
        cancelText: "отмена",
        applyText: "выбрать"
    };
    $.extend($.asColorPicker.defaults.buttons, localization);
})(jQuery);