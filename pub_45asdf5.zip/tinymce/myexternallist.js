var tinyMCELinkList = new Array(
    // Name, URL
    ["Moxiecode", "http://www.moxiecode.com"],
    ["Freshmeat", "http://www.freshmeat.com"],
    ["Sourceforge", "http://www.sourceforge.com"]
);