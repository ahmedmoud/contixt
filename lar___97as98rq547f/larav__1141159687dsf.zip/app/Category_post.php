<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_post extends Model
{
    protected $table = 'category_post';
}