<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comp_Image extends Model
{
    protected $table = 'Comp_images';
}
