<?PHP

namespace App\Modules\SEOAgent\Facade;

class SEOAgent extends \Illuminate\Support\Facades\Facade
{
    
    public static function getFacadeAccessor(){
        return 'SEOAgent';
    }
    
}