<?PHP

namespace App\Modules\mobileDetect\Facade;

class mobileDetect extends \Illuminate\Support\Facades\Facade
{
    
    public static function getFacadeAccessor(){
        return 'mobileDetect';
    }
    
}