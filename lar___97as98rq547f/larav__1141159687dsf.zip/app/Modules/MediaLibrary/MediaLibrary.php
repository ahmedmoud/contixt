<?php


namespace App\Modules\MediaLibrary;

$GLOBALS['LoadedImgs'] = [];

class MediaLibrary{
    public const IMAGE = 1;
    public const FILE = 2;
    public function find($id, $size){
        $media = Model::find($id);
        if(@ $media->url->$size ){
            return url($media->url->$size);
        }
        foreach( $media->url as $s ){
            return url($s);
        }
    }
    
    public function ClearifyAttach($media, $size){
        if( empty($media) || !$media || $media == null ) return ''; 
        $media = json_decode($media);
        if(@ $media->$size ){
            return $this->CDNmodifier($media->$size);
        }
        if( $media && $size = 'max' ){
            if( @$media->medium ) return $this->CDNmodifier($media->medium);
            if( @$media->small ) return $this->CDNmodifier($media->small);
        }
        if( $media && $size = 'medium' ){
            if( @$media->small ) return $this->CDNmodifier($media->small);
        }
        foreach( $media as $s ){
            return $this->CDNmodifier($s);
        }
    }

    public function CDNmodifier($url){
        //return url($url);
        $url = url($url); 

        $url = explode('/uploads', $url);
        $url = trim(end($url));

        $url = env('MAX_CDN_DOMAIN').$url;        
        
        return $url;
    }
    
    
}
