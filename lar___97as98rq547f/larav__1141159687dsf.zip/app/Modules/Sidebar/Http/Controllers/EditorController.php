<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 5:01 PM
 */

namespace App\Modules\Sidebar\Http\Controllers;

use App\Http\Controllers\Controller;
use Sidebar;

class EditorController extends Controller
{
    public function index(){
        $sidebars = Sidebar::bars();
        return view('sidebar::editor', compact('sidebars'));
    }
}