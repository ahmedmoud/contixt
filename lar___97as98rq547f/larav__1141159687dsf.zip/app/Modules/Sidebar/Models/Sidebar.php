<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 12:09 PM
 */

namespace App\Modules\Sidebar\Models;
use Illuminate\Database\Eloquent\Model;
use App\Modules\Sidebar\Models\Widget;

class Sidebar extends Model
{
    protected $table = 'sidebars';
    public $timestamps = false;
    protected $fillable = ['name'];
    public function widgets(){
        return $this->hasMany('App\Modules\Sidebar\Models\Widget');
    }
}