<?php


namespace App\Modules\Sidebar;
use App\Modules\Sidebar\Models\Sidebar as SidebarModel;
use App\Modules\Sidebar\Models\Widget;
use View;
use File;
use Http;
use Illuminate\Support\Facades\DB;
use App\Category;
use Cache;
use Auth;
use Mobile;

class Sidebar

{
    protected $type;
    protected $sidebars;
    public function __construct($type = 1){
        $this->type = $type;
     
        $is_AMP_ = isset($_GET['amp']) ? 'AMP_' : '';
        
        $this->sidebars = \Cache::remember('sideBar__bar_'.$is_AMP_.$type, 60*24, function(){
            return SidebarModel::all();
        });
        
    }

    public static function __callStatic($name, $arguments)
    {
        if(strtolower($name) == 'widget'){
            return new self(2);
        }
    }

    public function __get($name)
    {
        if($name == 'type'){
            return $this->type == 1 ? 'sidebar' : 'widget';
        }
    }

    public function bars(){
        return $this->sidebars;
        
    }
    
    public function hasWidgets($sidebar){
    	$target = false;
    
    	foreach($this->sidebars as $sbar){
            if($sbar->id == $sidebar || $sbar->name == $sidebar){
                $target = $sbar;
            }
        }
        return $target ? true : false;
    
    }

    public function widgets($sidebar){
        
        $is_mobile = Mobile::isMobile() ? 'MOB___' : 'DESK___';
        $is_AMP = isset($_GET['amp']) ? '_AMP_' : '';
      
        return Cache::remember('sidebarWidgets___'.$is_AMP.'_'.$is_mobile.'__'.$sidebar.'_'.\APP::getLocale(), 24*60, function() use ($sidebar) {
            
        $target = false;
        foreach($this->sidebars as $sbar){
            if($sbar->id == $sidebar || $sbar->name == $sidebar){
                $target = $sbar;
            }
        }
        return $target ? $target->widgets()->orderBy('order', 'ASC')->get() : false;
        });
    }

    public function render(Widget $widget, $html=null){

        if($widget->content->type == 'html'){
            return $this->renderHTML($widget, $html);
        }elseif($widget->content->type == 'posts'){
            return $this->renderPosts($widget);
        }
    }

    public function renderHTML(Widget $widget, $args=null){
        
        $output =  '<div class="widget widget-html col-md-'.@$widget->content->width.' __'.$widget->id.'">';

        if( $widget->title && !empty($widget->title)  && $widget->title != 'null' ){
            $output .= $args['title']['before'] ?? config('sidebar.sidebar.markup.html.title.before', '<h1 class="widget-title">');
            
            $output .= $widget->title;
            
            $output .= $args['title']['after'] ?? config('sidebar.sidebar.markup.html.title.after', '</h1>');
        }

        $output .= '<div class="widget-content">';

        $wcont = $widget->content->content;
        preg_match('#\[(.*?)Ad_placement="(.*?)"(.*?)\]#', $wcont, $out );
        if( isset($out) && isset($out[1]) && $out[1] ){
           $out = explode(',', $out[2]);
           $DesktopAd = @trim($out[0]);
           $MobileAd = @trim($out[1]);
           
           $DesktopAd = intval($DesktopAd);
           $MobileAd = intval($MobileAd);
            
           $DesktopAd = $DesktopAd && $DesktopAd > 0 ? $DesktopAd : false;
           $MobileAd = $MobileAd && $MobileAd > 0 ? $MobileAd : false;
           
           $content = '';

            // if( Mobile::isMobile() ){
            //     $ad = \DB::table('ads')->where('id', $DesktopAd)->where('status', 1)->select('code')->first();
            // }else{
            //     $ad = \DB::table('ads')->where('id', $DesktopAd)->where('status', 1)->select('code')->first();
            // }

            $ad =  app('App\Http\Controllers\Admin\AdsController')->getCode($DesktopAd,$MobileAd);

            if( $ad ){
                $content = $ad;
            }

        }else{
            $content = $widget->content->content;
        }

        $output .= $content;
        $output .= '</div>';
        
	    $output .= '</div>';
        return $output;
    }

    public function renderPosts(Widget $widget, $args=null){
    
        $identifier = $widget->id.'__'.$widget->sidebar_id;
        $is_AMP_ = isset($_GET['amp']) ? 'AMP_' : '';
      $compiled = Cache::remember('__widget_'.$identifier.$is_AMP_.'_'.\APP::getLocale(), 60, function() use ($widget){

        $posts = $this->getPosts($widget);
     
        if($posts){
            
        //$compiled = Blade::compileString(view('components.sidebar.'.$widget->content->template, compact('posts', 'widget')));
        if( $widget->content->postsOrcategories == 'cats' ){
            $the_cat = Category::where('id', $widget->content->category)->first();
        }else{
            $the_cat = false;
        }


        $thePath = isset($_GET['amp']) ? 'AMP.templates.' : 'components.sidebar.';
        

        $compiled = View::make($thePath.$widget->content->template, compact('posts', 'widget','the_cat'));
        $compiled = $compiled->render();
        return $compiled;

        
		return $compiled;
		}
		return false;
      });
        return $compiled;
    }

    public function getPosts($widget){
        
        $content = $widget->content;
        
 /*
	$category = \App\Category::find($content->category);
	if(!$category){
		return false;
	}
       */  
        //$posts = $category->posts()->limit($content->count)->whereNotIn('id', $GLOBALS['posts']);
$oldPosts =$GLOBALS['posts'];
        $allCats = $content->category;
if( $content->postsOrcategories == 'cats' && $content->postsIDs ){

if($allCats == '*'){
    $allCats = [];
    
}else{
    $the_cat = Category::where('id', $allCats)->first();
    $allCats = $the_cat->children->pluck('id')->toArray();
    $allCats[] = $the_cat->id;
}

        $posts  = DB::table('posts_images as posts')->whereIn('posts.type',['post','video'])->where('posts.created_at','<=',  \Carbon\Carbon::now() )->where('posts.status', 1)->where('posts.lang', \App::getLocale() )->
        join('category_post','category_post.post_id','=','posts.id')
        ->join('categories','categories.id','=','category_post.category_id');
        if( $widget->id != 26 || $widget->id != 15   ){
        $posts = $posts->whereNotIn('posts.id', $oldPosts );
        }
        if(  count($allCats) > 0){
          $posts = $posts->whereIn('categories.id',$allCats);
        }
        $posts = $posts->select('posts.id','posts.created_at','posts.views','posts.slug','posts.title','posts.Murl','posts.Malt','posts.excerpt','categories.name as cname', 'categories.slug as cslug','categories.color as ccolor' )->groupBy('posts.id')
        ->limit($content->count);

}else{
    $content->postsIDs = explode(',', $content->postsIDs);
        $posts  = DB::table('posts_images as posts')->where('posts.created_at','<=',  \Carbon\Carbon::now() )->where('posts.status', 1)->where('posts.lang', \App::getLocale() )->whereIn('posts.id', $content->postsIDs)->
        join('category_post','category_post.post_id','=','posts.id')
        ->join('categories','categories.id','=','category_post.category_id');
        
            if( !in_array($widget->id ,[26, 15] )  ){
                 $posts = $posts->whereNotIn('posts.id', $oldPosts );
            }
        
        $posts = $posts->select('posts.id','posts.created_at','posts.views','posts.slug','posts.title','posts.Murl','posts.Malt','posts.excerpt','categories.name as cname', 'categories.slug as cslug','categories.color as ccolor' )->groupBy('posts.id')
        ->limit($content->count);
}


        if($posts){ 
        

        if($content->order == 1){
            $posts = $posts->orderBy('views', $content->ordering == 1 ? 'ASC' : 'DESC');
        }elseif($content->order == 2){
            $posts = $posts->orderBy('posts.created_at', $content->ordering == 1 ? 'ASC' : 'DESC');
        }
     
                if( $widget->id != 33  ){
        $GLOBALS['posts'] = array_merge($GLOBALS['posts'], $posts->pluck('id')->toArray());
                }
        $the_posts = $posts->get();

        $ncat = Category::where('parent_id', $content->category)->select('slug','name')->limit(3)->get();
        if( $ncat && count($ncat) > 0) $the_posts[0]->category = $ncat;
        
        
        $NativeAdsssr = DB::table('nativeads')->where('widget_id', $widget->id )->get();
    if( $NativeAdsssr && 0 ){
        foreach( $NativeAdsssr as $NativeAdsss ){
        $NativeAds = $NativeAdsss->pid;
        $NativeAds = explode(',', $NativeAds);
        $NativeAds = array_map('trim', $NativeAds);
        

        foreach( $NativeAds as $NativeAd ){
            $c = $NativeAdsss->ord ? $NativeAdsss->ord : 1;
            $NativeAdsPost  = DB::table('posts_images as posts')->where('posts.created_at','<=',  \Carbon\Carbon::now() )->where('posts.status', 1)->where('posts.lang', \App::getLocale() )->where('posts.id', $NativeAd )->
            join('category_post','category_post.post_id','=','posts.id')
            ->join('categories','categories.id','=','category_post.category_id')->select('posts.id','posts.created_at','posts.views','posts.slug','posts.title','posts.Murl','posts.Malt','posts.excerpt','categories.name as cname', 'categories.slug as cslug','categories.color as ccolor' )->first();
            // dd( $NativeAdsPost );

            
            if( $NativeAdsPost ){

                $c--;
                $NativeAdsPost->category = $ncat;
                $the_posts[$c] = $NativeAdsPost;
            }
        }
        }
    }



        return $the_posts;
        }
        return false;
    }

    public function renderPost($post){
	if(config('sidebar.sidebar.markup.post.view')){
	dd(realpath(__DIR__.'/../../'));
	$file  = file_get_contents(__DIR__.'/../../../Sidebar.php');
dd($file);				

	}else{
	        $output = Http::ExtractLinkVars(config('sidebar.sidebar.markup.post.a.open'), $post);
	        $output .= config('sidebar.sidebar.markup.post.img.before', '<div class="media sidebar-media">');
	        $output .= Http::ExtractLinkVars(config('sidebar.sidebar.markup.post.img.self'), $post);
	        $output .= '<div class="media-body">';
	        $output .= '<h5 class="mt-0">مغامرات سوبر ماريو</h5>';
	        $output .= 'عبة سوبر ماريو المدى قد صدر';
	        $output .= '</div>';
	        $output .= '</div>';
	        $output .= '</a>';

	}
        return $output;
    }
}
