<?php

namespace App\Modules\Sidebar;

class Facade extends \Illuminate\Support\Facades\Facade{
    public static function getFacadeAccessor(){
        return 'App\Modules\Sidebar\Sidebar';
    }
}