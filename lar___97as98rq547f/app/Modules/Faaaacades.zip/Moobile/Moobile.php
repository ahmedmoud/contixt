<?php
namespace App\Modules\Moobile;


class Moobile
{

    public function yes(){
        return 'hi';
    }
}
