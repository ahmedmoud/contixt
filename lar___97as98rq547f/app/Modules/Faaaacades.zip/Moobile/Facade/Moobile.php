<?PHP

namespace App\Modules\Moobile\Facade;

class Moobile extends \Illuminate\Support\Facades\Facade
{
    
    public static function getFacadeAccessor(){
        return 'moobile';
    }
    
}