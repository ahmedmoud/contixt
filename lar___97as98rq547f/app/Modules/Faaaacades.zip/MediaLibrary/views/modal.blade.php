@push('media-styles')

<link rel="stylesheet" href="{{ asset('/vendor/media/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('/vendor/media/css/media.css') }}">
<link rel="stylesheet" href="{{ asset('/vendor/media/css/dropzone.css') }}">
@endpush
<div class="modal fade bs-example-modal-lg" data-target-id="" tabindex="-1" id="modalAlert" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;" alt-url="{{ url('/admin/media/ajaxSaveAlt') }}" >
 <div class="modal-dialog modal-lg">
     <div class="modal-content">
         <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
             <h4 class="modal-title" id="myLargeModalLabel">مكتبة الوسائط</h4> </div>
             <ul class="nav nav-tabs" role="tablist">
                 <li role="presentation" class="active nav-item"><a href="#upload" class="nav-link" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true"><span class="visible-xs"><i class="ti-home"></i></span><span class="hidden-xs">رفع جديد</span></a></li>
                 <li role="presentation" class="nav-item" id="chooseFromMedia"><a href="#choose" class="nav-link" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false"><span class="visible-xs"><i class="ti-pencil"></i></span> <span class="hidden-xs">اختيار</span></a></li>
             </ul>
         <div class="modal-body">
            
           <div class="tab-content">
               <div role="tabpanel" class="tab-pane" id="choose">
                   
                   <div class="col-md-8" style="float:right;">
                       <div id="mediaIMGS"></div>
                   </div>
                   <div class="col-md-4" style="float:left;">

                       <div id="Selection"></div>
                   </div>
               </div>
               <div role="tabpanel" class="tab-pane active" id="upload">
                 <div class="row">
                  <div class="col-md-12">
                    <div class="white-box">
                      <h5 class="box-title m-b-10">قم بسحب الملفات والقائها او اضغط بالأسفل للختيار </h5>
<div class="image_upload_div">
    <form action="{{ url(config('media.routes.upload')) }}" class="dropzone"></form>
</div>                    </div>
                  </div>
                </div>
               </div>
             </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal" id="ok_btn">OK</button>
         </div>
     </div>
     <!-- /.modal-content -->
 </div>
 <!-- /.modal-dialog -->
</div>
@push('media-scripts')
<script src="{{ asset('/vendor/media/js/jquery.min.js') }}"></script>
<script src="{{ asset('/vendor/media/js/dropzone.js') }}"></script>
<script src="{{ asset('/vendor/media/js/bootstrap.min.js') }}"></script>
<script>
    var routes = {!!  json_encode(config('media.routes')) !!};
</script>
<script src="{{ asset('/vendor/media/js/serializeJSON.js') }}"></script>
<script src="{{ asset('/vendor/media/js/media.js?v=1.1') }}"></script>
@endpush
