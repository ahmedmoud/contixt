<?php
namespace App\Modules\MediaLibrary;


use Illuminate\View\View;
use App\Modules\MediaLibrary\Model;

class LibraryViewComposer{

    public function compose(View $view){
        return $view->with('media', Model::where('type',1)->get());
    }
}
