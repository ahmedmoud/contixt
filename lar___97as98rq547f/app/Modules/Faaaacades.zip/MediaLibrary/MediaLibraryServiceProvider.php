<?php

namespace App\Modules\MediaLibrary;

use Illuminate\Support\ServiceProvider;
use Blade;
use View;

class MediaLibraryServiceProvider extends ServiceProvider{

    public function register(){
        
    }
    public function boot(){
        $this->registerDirectives();
         $this->app->alias('App\Modules\MediaLibrary\MediaLibrary','Media');
        $this->loadViewsFrom(__DIR__.'/views', 'media');
        $this->loadMigrationsFrom(__DIR__.'/database/migrations');
        $this->loadRoutesFrom(__DIR__.'/Http/routes.php');
        View::composer(['media::modal'], 'App\Modules\MediaLibrary\LibraryViewComposer');
        $this->publishes([
            __DIR__.'/assets' => public_path('/vendor/media')
        ], 'public');
        $this->publishes([
            __DIR__.'/config.php' => config_path('media.php')
        ], 'config');
    }

    public function registerDirectives(){
        Blade::directive('ifWith', function($args){
            return '<?php if(isset($args) && $args || !isset($args)): ?>';
        });
        Blade::directive('setIfNot', function($args){
            if(str_contains($args,',')){
                $args = explode(',', $args);
            }
            if(count($args) > 1){
                return '<?php if(!isset('. $args[0] .')){
                    '. $args[0] .' = '. $args[1] .';
                } ?>';
            }else{
                throw new Exception('setIfNot required two Arguments');
            }
        });
    }
}
