<?php
namespace App\Modules\SEOAgent;

include ( __DIR__.'/simple_html_dom.php' );

class SEOAgent
{
    // public $text, $title, $keyword;

    public function fetchReport($post){
        $output = $this->analyse($post);
        $out = '';
        $before = '<li>';
        $after = '</li>';
        foreach( $output as $state ){
            if( !$state ) continue; 

            if( is_array($state) ){
                foreach( $state as $stat ){ $out .= $before.$stat.$after; }
            }else{
                $out .= $before.$state.$after;
            }
        }
        if( !$out ) return false;
       return '<ul>'.$out.'</ul>';
    }
    
    private function analyse( $post ){


        $this->text = $post->content;
        $this->title = $post->title;
        $this->keyword = str_replace('-', ' ', urldecode($post->slug) );
        $this->metaDesc = $post->excerpt;

        $output = Collect();
        $output->kwDenisty = $this->kwDenisty();
        $output->countText = $this->countText();
        $output->title = $this->Title();
        $output->metaDesc  = $this->metaDes();
        $output->images    = $this->Images();
        $output->headings  = $this->Headings();
        $output->OutboundLinks   = $this->ahrefs();
        
        $output =  (array)$output;
        return $output;

    }


    private function getHTML(){
        return str_get_html( $this->text );
    }

    public function ahrefs(){
        $html = $this->getHTML();
        
        foreach( $html->find('a') as $key=>$a ){
            if( $a->rel ){
                $type = strtolower($a->rel) == 'dofollow' ? 'dofollow' : 'nofollow';
            }else{
                $type = 'dofollow';
            }
            $types[$type][] = [
                'type' => $type,
                'link' => $a->plaintext,
                'out' => str_contains(url('/'), $a->href)
            ];

        }
        $types['nofollow'] = isset($types['nofollow']) ? $types['nofollow'] : 0;
        if( $types['nofollow'] == 0 ) return false;
       return 'يوجد '.count( $types['nofollow'] ).' رابط خارجي';

    }

    private function Headings(){
        $html = $this->getHTML();
        $m = 0; $n = 0; $msg = [];
        foreach( $html->find('h2,h3,h4') as $s){
            $txt = $s->plaintext;
            if( !str_contains($txt, $this->keyword ) ){ $m++; }else{ $n++; }
        }

        if( !$n || $n < 1 ){ return 'لم يتم استخدام الكلمة الاساسية في اي من العناوين مثل h2'; }
        return false;
    }
    private function Title(){
        if( !str_contains( $this->title, $this->keyword ) ){
            return 'الكلمة الاساسية لم يتم استخدمها في العنوان';
        }
        return false;
    }

    private function paragraph(){
        $html = $this->getHTML();
        $p = $html->find('p');
        return $p;
    }

    private function firstParagraph(){
        $p = $this->paragraph();
        if( !$p ) return 'المحتوى لا يحتوى على وسوم براجراف p';

        if( $p[0] ){
            $p = $p[0];
            if( !str_contains( $this->title, $this->keyword ) ){
                return 'الكلمة الاساسية لم يتم استخدمها في اول براجراف p';
            }
            return true;
        }
        return 'المحتوى لا يحتوى على وسوم براجراف p';
    }

    private function Images(){

        $msg = [];
        $html = $this->getHTML();
        $s = 0;
        foreach( $html->find('img') as $key=>$img ){
            if( !$img->alt || empty($img->alt) ){
                $msg[] = 'الصورة '.++$key.' : لا تحتوى على ALT. ';
            }elseif( str_contains( $img->alt, $this->keyword ) ){
                $s++;
            }
            
            
        }
        if( $s == 0 ){
            $msg[] = ' ALT للصورة  : لا يحتوي على الكلمة الاساسية';
        }
        return $msg;
    }

    private function countText(){
        $count = $this->TextLength();
        return  $count < 300 ? 'لا يجب ان يقل المحتوى عن 500 كلمة ، الحالي '.$count : false;
    }
    private function TextLength(){
        $text = preg_replace('!\s+!', ' ', $this->text);
        $text = explode(' ', $text);
        $count = count($text);
        return $count;
    }
    private function countTitle(){
        $text = preg_replace('!\s+!', ' ', $this->title);
        return strlen($text);
    }

    private function txtCheck($text){
        $text = trim($text);
        $text = preg_replace('!\s+!', ' ', $text );
        if( empty($text) ) return false;
        return strlen( $text );
    }
    private function txtLength($text){
        $text = trim($text);
        $text = preg_replace('!\s+!', ' ', $text );
        if( empty($text) ) return false;
        $text = explode(' ', $text);
        return count( $text );
    }

    private function metaDes(){
        $length = $this->txtCheck( $this->metaDesc ) / 2;
        $metaDescriptionLengthMin = 150;
        $metaDescriptionLengthMax = 300;
        $msg = [];
        if( !str_contains($this->metaDesc, $this->keyword) ){
            $msg[] = 'الكلمة الاساسية غير موجوده في الوصف القصير.';
        }
        if( $length < $metaDescriptionLengthMin ){
            $diff = $metaDescriptionLengthMin - $length;
            $msg[] = 'الوصف القصير لا يجب أن يقل عن '.$metaDescriptionLengthMin.' حرف ، باقي لك '.$diff.' حرف.';
        }elseif( $length > $metaDescriptionLengthMax ){
            $msg[] = 'الوصف القصير لا يجب ان يزيد عن '.$metaDescriptionLengthMax.' ، الحالي '.$length;
        }
        return count($msg) > 0 ? $msg : false;
    }

    private function kwDenisty(){
        $word_count = $this->TextLength();
        $keyword = $this->keyword;
        $keyword_count = preg_match_all("#{$keyword}#si", $this->text , $matches);
        //$keyword_count = count($matches);
        $density = $keyword_count / $word_count * 100;
        $density = number_format($density, 2);
        return $density < 1.5 ? 'كثافة الكلمة الاساسية لا يجب ان تقل عن 1.5% ، الحالي '.$density.'%' : false;
    }

    
}