<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 5:01 PM
 */

namespace App\Modules\Sidebar\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Sidebar;
use DB;
use App\Modules\Sidebar\Models\Widget;
use App\Modules\Sidebar\Models\Sidebar as Side;
use Setting;

class SidebarController extends Controller
{
    public function index(){
        return view('sidebar::editor');
    }

    public function get(Request $request){
     
        if($request->bar && $request->bar != 'null'){
            return Sidebar::widgets($request->bar);
        }else{
            return Sidebar::bars();
        }
    }
    public function store(Request $request){
        $request->validate([
            'name' => 'required'
        ]);

        $sidebar = Side::create($request->except('_token'));


        return $sidebar;
    }

    /**
     * @param Widget $widget
     * @param Request $request
     * @return mixed
     */
    public function put($widget, Request $request){
      
        abort_if(!$widget = Widget::find($widget), 404);
        $body = $request->except('_token');
/*
        if($request->order > $widget->order){
            $sibling = Widget::where('sidebar_id', $widget->sidebar_id)->where('order', '=', $request->order)->first();
         
            if($sibling && $sibling->count()){
                $sibling->decrement('order');
            }
        }else if($request->order < $widget->order){
            $sibling = Widget::where('sidebar_id', $widget->sidebar_id)->where('order', '=', $request->order)->first();
            if($sibling->count()){
                $sibling->increment('order');
            }
        }
        */
        $c = 0;
        foreach($request->order as $one){
            $e = Widget::where('id',$one)->first();
            $e->order = ++$c;
            $e->save();
        }
        return 'yes';
//        DB::transaction(function () use ($request, $widget){
//
//            return $widget;
//
//            foreach($widgets as $one){
//                $one->order += 1;
//                $one->save();
//            }
//        });

    }
    public function AddLocation(Request $request){
        Setting::set($request->value, $request->key);
        Setting::save();
        return Setting::get($request->key);
    }
}