<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/9/18
 * Time: 12:39 PM
 */

namespace App\Modules\Sidebar\Http\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Sidebar\Models\Widget;
use Illuminate\Http\Request;

class WidgetController extends Controller
{
    /**
     * @param Request $request
     */
    public function store(Request $request){
        $request->validate([
            'title' => 'nullable',
            'content' => 'required'
        ]);

        $body = $request->except('_token');
        $order = Widget::where('sidebar_id', $body['sidebar_id'])->first();
        $order = @isset($order) && $order->order ? $order->order + 1 : 1;
        $body['order'] = $order;
        abort_if(!$widget = Widget::create($body), 422);
        return $widget;
    }
    public function update($widget, Request $request){

        $request->validate([
            'title' => 'nullable',
            'content' => 'required'
        ]);
        abort_if(!$widget = Widget::find($widget), 404);

        $body = $request->except('_token');
        $body['content']['type'] = $widget->content->type;
        $widget->update($body);
        return $widget;
    }
    public function destroy($widget){
        abort_if(!$widget = Widget::find($widget), 404);

        $widget->delete();

        return $widget;
    }
}