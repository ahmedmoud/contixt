<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 4:49 PM
 */

Route::group(['namespace' => 'App\Modules\Sidebar\Http\Controllers'], function(){
//    Route::get(config('sidebar.editor.routes.base'), 'EditorController@index');
    Route::get(config('sidebar.editor.routes.sidebar.get'), 'SidebarController@get');
    Route::post(config('sidebar.editor.routes.sidebar.store'), 'SidebarController@store');
    Route::put(config('sidebar.editor.routes.sidebar.put'), 'SidebarController@put');
    Route::post(config('sidebar.editor.routes.widget.store'), 'WidgetController@store');
    Route::put(config('sidebar.editor.routes.widget.update'), 'WidgetController@update');
    Route::delete(config('sidebar.editor.routes.widget.delete'), 'WidgetController@destroy');
    Route::post(config('sidebar.editor.routes.location'), 'SidebarController@AddLocation');
});
//Route::view('/editr', 'sidebar::editor');