<?php

return [
    'locations' => [],
    'editor' => [
        'routes' => [
            'base' => '/admin/editor',
            'location' => 'location',
            'sidebar' => [
                'get' => '/sidebar/editor/get',
                'put' => '/sidebar/editor/{id}',
                'store' => '/sidebar/'
            ],
            'widget' => [
                'store' => '/widgets',
                'delete'=> '/widgets/{id}'
            ]
        ]
    ],
    'sidebar' => [
        'markup' => [
            'posts' => [
                'container'=>[
                    'before'=>'<div class="widget widget-posts sssssssssssssssssssss">',
                    'after' => '</div>'
                ],
                'title' => [
                    'before' => '<h1 class="widget widget-title">',
                    'after' => '</h1>'
                ],
                'content' => [
                    'before' => '<div class="widget widget-content">',
                    'after' => '</div>'
                ]
            ],
            'html' => [
                'container'=>[
                    'before'=>'<div class="widget widget-html">',
                    'after' => '</div>'
                ],
                'title' => [
                    'before' => '<h1 class="widget widget-title">',
                    'after' => '</h1>'
                ],
                'content' => [
                    'before' => '<div class="widget widget-content">',
                    'after' => '</div>'
                ]
            ]
        ]
    ]
];