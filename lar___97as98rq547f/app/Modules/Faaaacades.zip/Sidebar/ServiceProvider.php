<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 11:49 AM
 */

namespace App\Modules\Sidebar;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider as LaravelServiceProvider;
use Illuminate\Foundation\AliasLoader;

/**
 * @property  app App
 */
class ServiceProvider extends LaravelServiceProvider
{

    public function register(){
        $this->app->singleton('SidebarManager', function($app){
            return new SidebarManager($app);
        });
        $this->app->singleton('Sidebar', function($app){
            return $app->make('SidebarManager')->driver();
        });

        $loader = AliasLoader::getInstance();
        $loader->alias('Sidebar', 'App\Modules\Sidebar\Facade');
    }
    public function boot(){
        $this->loadMigrationsFrom(__DIR__. '/database/migrations');
        $this->loadViewsFrom(__DIR__.'/views', 'sidebar');
        $this->loadRoutesFrom(__DIR__.'/Http/routes.php');
        $this->publishes([
            __DIR__.'/assets' => public_path('vendor/sidebar')
        ],'public');
        $this->publishes([
            __DIR__.'/config.php' => config_path('sidebar.php')
        ],'config');

        View::composer('sidebar::editor', 'App\Modules\Sidebar\Composers\SidebarComposer');
    }
}