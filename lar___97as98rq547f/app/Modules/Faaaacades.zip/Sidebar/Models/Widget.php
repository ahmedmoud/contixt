<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 12:13 PM
 */

namespace App\Modules\Sidebar\Models;


use Illuminate\Database\Eloquent\Model;

class Widget extends Model
{
    protected $table = 'sidebars_widgets';
    protected $fillable = ['title', 'content','sidebar_id', 'order'];
    public $timestamps = false;
    protected $casts = ['content' => 'object'];
    public function sidebar(){
        return $this->belongsTo('Sidebar');
    }
}