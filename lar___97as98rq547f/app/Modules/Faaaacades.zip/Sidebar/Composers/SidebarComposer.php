<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/12/18
 * Time: 12:34 PM
 */

namespace App\Modules\Sidebar\Composers;

use App\Modules\Sidebar\Models\Sidebar;
use Illuminate\View\View;

class SidebarComposer
{
    /**
     * @param View $view
     */
    public function compose(View $view){
        $sidebars = Sidebar::all();
        $view->with('sidebars', $sidebars);
    }
}