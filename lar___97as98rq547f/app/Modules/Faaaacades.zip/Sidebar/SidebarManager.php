<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 11:52 AM
 */

namespace App\Modules\Sidebar;

use Illuminate\Support\Manager;
class SidebarManager extends Manager
{
    public function getDefaultDriver()
    {
        return 'database';
    }

    public function createDatabaseDriver()
    {
        return new Sidebar();
    }
}