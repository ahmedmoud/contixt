<?php
/**
 * Created by PhpStorm.
 * User: salemcode8
 * Date: 5/7/18
 * Time: 11:49 AM
 */

namespace App\Modules\Sidebar;
use App\Modules\Sidebar\Models\Sidebar as SidebarModel;
use App\Modules\Sidebar\Models\Widget;
use View;
use File;
use Http;
use Illuminate\Support\Facades\DB;
use App\Category;
use Cache;
use Auth;

class Sidebar

{
    protected $type;
    protected $sidebars;
    public function __construct($type = 1){
        $this->type = $type;
       // $sidebaaars = Cache::remember('ourSidebars', 60*24, function(){
            
      //  return SidebarModel::all();
       // });
        $this->sidebars = SidebarModel::all();
    }

    public static function __callStatic($name, $arguments)
    {
        if(strtolower($name) == 'widget'){
            return new self(2);
        }
    }

    public function __get($name)
    {
        if($name == 'type'){
            return $this->type == 1 ? 'sidebar' : 'widget';
        }
    }

    public function bars(){
       
        return $this->sidebars;
    }
    
    public function hasWidgets($sidebar){
    	$target = false;
    
    	foreach($this->sidebars as $sbar){
            if($sbar->id == $sidebar || $sbar->name == $sidebar){
                $target = $sbar;
            }
        }
        return $target ? true : false;
    
    }

    public function widgets($sidebar){
        
        return Cache::remember('sidebarWidgets___'.$sidebar, 24*60, function() use ($sidebar) {
            
        $target = false;
        foreach($this->sidebars as $sbar){
            if($sbar->id == $sidebar || $sbar->name == $sidebar){
                $target = $sbar;
            }
        }
        return $target ? $target->widgets()->orderBy('order', 'ASC')->get() : false;
        });
    }

    public function render(Widget $widget, $html=null){

        if($widget->content->type == 'html'){
            return $this->renderHTML($widget, $html);
        }elseif($widget->content->type == 'posts'){
            return $this->renderPosts($widget);
        }
    }

    public function renderHTML(Widget $widget, $args=null){
        
        $output =  '<div class="widget widget-html col-md-'.@$widget->content->width.'">';

        if( $widget->title && !empty($widget->title)  && $widget->title != 'null' ){
            $output .= $args['title']['before'] ?? config('sidebar.sidebar.markup.html.title.before', '<h1 class="widget-title">');
            
            $output .= $widget->title;
            
            $output .= $args['title']['after'] ?? config('sidebar.sidebar.markup.html.title.after', '</h1>');
        }

        $output .= '<div class="widget-content">';

        $output .= $widget->content->content;

        $output .= '</div>';
        
	    $output .= '</div>';
        return $output;
    }

    public function renderPosts(Widget $widget, $args=null){

        $identifier = $widget->id.'__'.$widget->sidebar_id;
      $compiled = Cache::remember('__widget_'.$identifier, 60, function() use ($widget){
            
        
        $posts = $this->getPosts($widget->content);
        
        if($posts){
            
        //$compiled = Blade::compileString(view('components.sidebar.'.$widget->content->template, compact('posts', 'widget')));
        if( $widget->content->postsOrcategories == 'cats' ){
            $the_cat = Category::where('id', $widget->content->category)->first();
        }else{
            $the_cat = false;
        }


        $compiled = View::make('components.sidebar.'.$widget->content->template, compact('posts', 'widget','the_cat'));
        $compiled = $compiled->render();
        return $compiled;

        
		return $compiled;
		}
		return false;
      });
        return $compiled;
    }

    public function getPosts($content){
 //       dd($content);
 /*
	$category = \App\Category::find($content->category);
	if(!$category){
		return false;
	}
       */  
        //$posts = $category->posts()->limit($content->count)->whereNotIn('id', $GLOBALS['posts']);
$oldPosts =$GLOBALS['posts'];
        $allCats = $content->category;
if( $content->postsOrcategories == 'cats' && $content->postsIDs ){

if($allCats == '*'){
    $allCats = [];
    
}else{
    $the_cat = Category::where('id', $allCats)->first();
    $allCats = $the_cat->children->pluck('id')->toArray();
    $allCats[] = $the_cat->id;
}



        $posts  = DB::table('posts_images as posts')->where('posts.type','post')->where('posts.created_at','<=',  \Carbon\Carbon::now() )->where('posts.status', 1)->
        join('category_post','category_post.post_id','=','posts.id')
        ->join('categories','categories.id','=','category_post.category_id')
        ->whereNotIn('posts.id', $oldPosts );
        if(  count($allCats) > 0){
          $posts = $posts->whereIn('categories.id',$allCats);
        }
        $posts = $posts->select('posts.id','posts.created_at','posts.views','posts.slug','posts.title','posts.Murl','posts.Malt','posts.excerpt','categories.name as cname', 'categories.slug as cslug','categories.color as ccolor' )->groupBy('posts.id')
        ->limit($content->count);

}else{
    $content->postsIDs = explode(',', $content->postsIDs);
        $posts  = DB::table('posts_images as posts')->where('posts.created_at','<=',  \Carbon\Carbon::now() )->where('posts.status', 1)->whereIn('posts.id', $content->postsIDs)->
        join('category_post','category_post.post_id','=','posts.id')
        ->join('categories','categories.id','=','category_post.category_id')
        ->whereNotIn('posts.id', $oldPosts )->select('posts.id','posts.created_at','posts.views','posts.slug','posts.title','posts.Murl','posts.Malt','posts.excerpt','categories.name as cname', 'categories.slug as cslug','categories.color as ccolor' )->groupBy('posts.id')
        ->limit($content->count);
}

        if($posts){ 
        if($content->order == 1){
            $posts = $posts->orderBy('views', $content->ordering == 1 ? 'ASC' : 'DESC');
        }elseif($content->order == 2){
            $posts = $posts->orderBy('posts.created_at', $content->ordering == 1 ? 'ASC' : 'DESC');
        }
        $GLOBALS['posts'] = array_merge($GLOBALS['posts'], $posts->pluck('id')->toArray());
        $the_posts = $posts->get();
        
        $ncat = Category::where('parent_id', $content->category)->select('slug','name')->limit(3)->get();
        if( $ncat ) $the_posts[0]->category = $ncat;
            
        return $the_posts;
        }
        return false;
    }

    public function renderPost($post){
	if(config('sidebar.sidebar.markup.post.view')){
	dd(realpath(__DIR__.'/../../'));
	$file  = file_get_contents(__DIR__.'/../../../Sidebar.php');
dd($file);				

	}else{
	        $output = Http::ExtractLinkVars(config('sidebar.sidebar.markup.post.a.open'), $post);
	        $output .= config('sidebar.sidebar.markup.post.img.before', '<div class="media sidebar-media">');
	        $output .= Http::ExtractLinkVars(config('sidebar.sidebar.markup.post.img.self'), $post);
	        $output .= '<div class="media-body">';
	        $output .= '<h5 class="mt-0">مغامرات سوبر ماريو</h5>';
	        $output .= 'عبة سوبر ماريو المدى قد صدر';
	        $output .= '</div>';
	        $output .= '</div>';
	        $output .= '</a>';

	}
        return $output;
    }
}
