<link rel="stylesheet" href="{{ asset('vendor/sidebar/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/sidebar/css/sidebar.css') }}">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<script>
@php 

$main_cats = App\Category::select('id','name')->get();
$mmain_cats = array();
$mmain_cats[] = ['id'=>'*', 'name'=>'all'];
foreach( $main_cats as $mc ){
    $mmain_cats[] = ['id'=> $mc->id, 'name'=>$mc->name];
}
@endphp
    var main_cats = <?=json_encode($mmain_cats);?>;
</script>


        <link href="{{ asset('admin_panel/jquery-asColorPicker-master/css/asColorPicker.css') }}" rel="stylesheet" />


<script src="{{ asset('vendor/sidebar/js/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/sidebar/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('vendor/sidebar/js/serializeField.js') }}"></script>
<script src="{{ asset('vendor/sidebar/js/bootstrap.min.js') }}"></script>



    <script src="{{ asset('admin_panel/jquery-asColorPicker-master/libs/jquery-asColor.js') }}"></script>
    <script src="{{ asset('admin_panel/jquery-asColorPicker-master/libs/jquery-asGradient.js') }}"></script>
    <script src="{{ asset('admin_panel/jquery-asColorPicker-master/dist/jquery-asColorPicker.min.js') }}"></script>



<script>
    var routes = {!! json_encode(config('sidebar.editor.routes')) !!}
</script>
<script src="{{ asset('vendor/sidebar/js/editor.js') }}"></script>
<script src="{{ asset('vendor/sidebar/js/main.js') }}"></script>
<div class="modal fade" id="AddSidebarToLocationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Sidebar To Location</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="AddLocationForm">
                    <div class="form-group">
                        <label>Select Sidebar</label>
                        <select name="sidebar" class="form-control" id="sidebars-locations">
                            @foreach($sidebars as $sidebar)
                                <option value="{{ $sidebar->id }}"> {{$sidebar->name}} </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select Location</label>
                        <select name="location" class="form-control" id="location">
                            @foreach(config('sidebar.locations') as $key => $value)
                                <option value="{{ $key }}">{{ $value }}</option>
                            @endforeach
                        </select>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="SaveLocationBtn" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="AddWidgetModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Widget</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="AddWidgetForm">
                    <div class="form-group">
                        <label for="widget-title">Title</label>
                        <input name="title" id="widget-title" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Widget Type</label>
                        <fieldset name="content">
                            <select name="type" class="form-control"  id="widgetType">
                                <option value="html">HTML Code</option>
                                <option value="posts">Posts</option>
                            </select>
                            <div id="widgetContainer"></div>
                        </fieldset>
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="SaveWidgetBtn" type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="AddSidebarModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Sidebar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="AddSidebarForm">
                    <label>Sidebar Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Sidebar Name">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button id="SubmitSidebarBtn" type="button" class="btn btn-primary">Add Sidebar</button>
            </div>
        </div>
    </div>
</div>
<button class="btn btn-success" id="AddSidebarBtn" data-toggle="modal" data-target="#AddSidebarModal">Add Sidebar</button>
<button class="btn btn-success" id="AddWidgetBtn"  data-toggle="modal" data-target="#AddWidgetModal">Add Widget</button>
<button class="btn btn-success" id="AddWidgetBtn"  data-toggle="modal" data-target="#AddSidebarToLocationModal">Add Sidebar to Location</button>
<div class="row">

    <div class="col">
        <label for="sidebarSelect">Select a Sidebar to Edit</label>
        <select id="sidebarSelect" class="form-control">
            @foreach($sidebars as $sidebar)
                <option value="{{ $sidebar->id }}"> {{$sidebar->name}} </option>
            @endforeach
        </select>
    </div>
</div>

<div class="row">
    <div class="col" id="widgets"></div>
</div>



	<script>
	    
	     // Colorpicker
    $(".colorpicker").asColorPicker();
    $(".complex-colorpicker").asColorPicker({
        mode: 'complex'
    });

	    
	</script>