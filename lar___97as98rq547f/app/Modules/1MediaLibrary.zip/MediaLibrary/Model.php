<?php

namespace App\Modules\MediaLibrary;

class Model extends \Illuminate\Database\Eloquent\Model
{
    protected $table = 'media';
    protected $fillable = ['title','alt','description'];
    protected $casts = ['url' => 'object'];
}
