@php(throw_if(!isset($Mid), new \Exception('Media Id Is Required')))
<div class="form-group mediaParent" id="{{ $Mid }}">
    <div class="form-group row">
        <label class="col-2 col-form-label">{{ $Mtitle ?? 'Media' }}</label>
        <div class="col-10">
            <button type="button" data-custom-type="{{ $Mtiny ?? 'select' }}" class="featured-image btn" data-multi="{{ $Mtype ?? 1 }}" data-id="{{ $Mid }}">اضغط هنا لاختيار صورة <i class="fa fa-image" style="float: right; margin: 4px; "></i>  </button>
            <div class="imgParent">
            @isset($currentValues)
                @foreach( app(App\Modules\MediaLibrary\Http\Controllers\MediaController::class)->get_prev($currentValues) as $cValue )
                    <div class="featuredImagePlace">
                        <input type="hidden" name="{{ $Mid }}@if( is_array($currentValues) && count($currentValues) > 1 )[]@endif" value="{{ $cValue->id }}" />
                        <img src="{{ url($cValue->url->small) }}">
                        <span class="featuredimgClose">X</span>
                    </div>
                @endforeach
            @endisset
            </div>
        </div>
    </div>
</div>
