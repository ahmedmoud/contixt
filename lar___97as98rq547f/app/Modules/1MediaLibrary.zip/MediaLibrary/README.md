# Laravel Media Library

Media Library for Laravel

## Installation

1. Clone it Into app/Modules Directory in Laravel Project
2. Add `App\Modules\MediaLibrary\MediaLibraryServiceProvider` to the array of providers in `config/app.php`.
3. Don't Forget To run `composer dump-autoload` to Get the Package Working Correctly
4. Publish the config file and assets by running  `php artisan vendor:publish` The config file will give you control over Everything In the Package.

## Usage

```php
// example.blade.php
    // To Get The Modal 
      @include('media::modal')
    // To Get The Button
      @include('media::btn',[
      'Mid' => 'required > Id of the element that Will Display the Image',
      'Mtitle' => 'optional > Title Will Appears above the button',
      'Mtype' => 'optional > select if multiple or single [
        1 => 'single',
        2 => 'multiple'
      ]',
      'currentValues' => 'optional > the current images if there'
      ])
```

## Notes

    * You Have to Install [Image Intervention](http://image.intervention.io) To Use MediaLibrary 
    * You Have to Create ```uploads``` Directory inside your ```public```` Directory
