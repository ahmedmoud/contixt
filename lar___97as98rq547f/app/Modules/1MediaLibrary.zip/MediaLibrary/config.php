<?php

return [
    'routes' => [
        'base' => '/media',
        'get' => '/media/{id}',
        'update' => '/media/{id}',
        'upload' => '/media/upload'
    ]
];