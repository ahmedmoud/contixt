<?php

namespace App\Modules\MediaLibrary\Http\Controllers;

use Illuminate\Http\Request;
use App\Modules\MediaLibrary\Model as Media;
use Image;
use DB;
use App\Http\Controllers\Controller;

class MediaController extends Controller
{
    public function upload(Request $request){

       if($request->hasFile('file') && $request->file('file')->isValid() ) {
            $file       = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            $fileNAME    = $file->getClientOriginalName();
            $filename = time().'.'.$extension;
            $mime = $request->file->getClientMimeType();
           $type = '';
        if(substr($request->file->getClientMimeType(), 0, 5) == 'image') {
            $type = 'img';
            
            $image = $file;
            list($width, $height) = getimagesize($image->getRealPath());
    

            $image_resize = Image::make($image->getRealPath());
            
            //$sizes = "a:3:{s:8:\"original\";a:2:{i:0;i:3000;i:1;i:3000;}s:6:\"medium\";a:2:{i:0;i:600;i:1;i:700;}s:9:\"thumbnail\";a:2:{i:0;i:300;i:1;i:300;}}";
            //$sizes = unserialize($sizes);

            $sizes = [ // width, height, max size to optimize
                'tiny' => [100, 55, 2.5 ],
                'small'=> [167, 106, 4],
                'medium'=>[318, 235, 7],
                'max'=>[750, 750, 50]
            ];

            $c = 0;
            $output = array();

          
/*
                $imgName = 'uploads/up_'.$filename;
                $image_resize->resize( $image_resize->width(), $image_resize->height() );
                $image_resize->save(public_path($imgName));
                $output['uploaded'] = $imgName;
*/
$qualitys = '';
            foreach( $sizes as $key=>$size ){
                  
                  
                $image_resize = Image::make($image->getRealPath());

                /*
                if( $image_resize->width() < $size[0] ){

                $imgName = 'uploads/'.$key.'_uploads/'.date('Y/m/').$imgName;
                $pathaa = pathinfo($imgName);
                if (!file_exists($pathaa['dirname'])) { mkdir($pathaa['dirname'], 0777, true); }

                $output[$key] = $imgName;
                $image_resize->save(public_path($imgName));
                    continue;
                }
                */
                if( $width >= $size[0] ){

                    if( $size == 'tiny' || $size == 'small' || $size == 'medium' ){
                        $image_resize->resize($size[0], $size[1]);
                    }else{
                        $image_resize->resize($size[0], null, function ($constraint) {
                            $constraint->aspectRatio();
                        });
                    }
                }
                $imgName = 'uploads/'.$key.'_uploads/'.date('Y/m/').$filename;
                $pathaa = pathinfo($imgName);
                if (!file_exists($pathaa['dirname'])) { mkdir($pathaa['dirname'], 0777, true); }
                $FileSize = strlen( (string)$image_resize->encode() );
                $FileSize = round($FileSize/1024);
                $SizeQuality = $size[2];
                if( $FileSize > $SizeQuality ){
                    $diff = ( $FileSize - $SizeQuality ) / $FileSize;
                    $diff = 100 * $diff;
                    $diff = round(100 - $diff, 2);
                    
                    $quality = $FileSize > $SizeQuality ? $diff : 100;
                    $quality = $quality > 80 ? 80 : $quality;
                    $image_resize->save( public_path($imgName), $quality );
                    $qualitys .= $quality."\n";
                }else{
                    $image_resize->save( public_path($imgName) );
                }

                $output[$key] = $imgName;
                
                $c++;
            }
            
        }else{

           $video_ex = ['flv','mp4','m3u8','ts','3gp','mov','avi','wmv'];
           $video_mime = ['video/x-flv','video/mp4','application/x-mpegURL','video/MP2T','video/3gpp','video/quicktime','video/x-msvideo','video/x-ms-wmv'];
            
            if( in_array($mime, $video_mime) || in_array($extension, $video_ex) ){
                $type = 'video';
            }

               $path = $file->storeAs('uploads', $filename);
        }

        $ِAttach = new Media();
       $ِAttach->title = $filename;
        $ِAttach->alt = '';
        $ِAttach->url = $output;
        $ِAttach->type = 1;
        $ِAttach->save();
        dd($ِAttach);
        return $ِAttach->ID;
    }

}

    public function getUploads(){
        
        return view('Admin.Attachement.upload');
    }

    public function update($id, Request $request){
        abort_if(!$media = Media::find($id), 404);
        $body = $request->except('_token', '_method');
        $media->update($body);
        return $media;
//        $output = DB::table('attatchments')->where('id', $id)->update(['alt' => $alt]);
//       if( $output ){
//          return  '<b style="color:green;">تم الحفظ بنجاح</b>';
//        }else{
//
//        return '<b style="color:red;">تحدث خطأ ما</b>';
//           }
    }

    public function ajax($size = 'small'){  
       
        $attachments = Media::where('type',1)->orderBy('ID','desc')->limit(15)->get();
        foreach( $attachments as $key => $attach ){
            $ss = ( isset($attach->url->max) )? $attach->url->max : false;
            if( !$ss ) { $ss = ( $attach->url->medium )? $attach->url->medium : false; }
            if( !$ss ) { $ss = ( $attach->url->small )? $attach->url->small : false; }
            if( !$ss ) { $ss = ( $attach->url->tiny )? $attach->url->tiny : false; }
            
        if( $ss && file_exists($ss) ){
            list($width, $height) = getimagesize($ss);
            $attach->width = $width;
        }
       if( $attach ){
           if( isset($attach->url->$size) ){
               $attachments[$key]->src = url($attach->url->$size);
           }
       }
    }
        return $attachments;
//        return view('Admin.Attachement.ajax',compact('attachments'));
    }    
    
    public function get_prev($ids){
        $size = 'thumbnail';
        $ids = ( is_array($ids) )? $ids : [$ids];
        $attachments = Media::where('type','!=','user')->whereIn('ID', $ids)->get();
        foreach( $attachments as $attach ){
        
           if( $attach ){
               $attachh = unserialize($attach->path);

               if( isset($attachh[$size]) ){
                   $attach->src = $attachh[$size];
               }
           }
        }
        return $attachments;
    }
    
    public function get($id){
        abort_if(!$media = Media::find($id), 404);
        return $media;
    }
    
        
}