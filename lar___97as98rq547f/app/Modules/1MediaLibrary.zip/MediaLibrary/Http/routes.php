<?php
Route::group(['namespace' => 'App\Modules\MediaLibrary\Http\Controllers'], 
	function(){
		Route::get(config('media.routes.base'), 'MediaController@ajax');
		Route::get(config('media.routes.get'), 'MediaController@get');
		Route::put(config('media.routes.update'), 'MediaController@update');
//		Route::post(config('media.routes.upload'),'MediaController@store');
		Route::post(config('media.routes.upload'),'MediaController@upload');
//		Route::post(config('media.routes.get'),'MediaController@ajax');

	}
);