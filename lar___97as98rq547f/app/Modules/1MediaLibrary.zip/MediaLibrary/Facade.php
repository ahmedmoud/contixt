<?php

namespace App\Modules\MediaLibrary;

class Facade extends \Illuminate\Support\Facades\Facade{
    protected static function getFacadeAccessor(){
        return 'App\Modules\MediaLibrary\MediaLibrary';
    }
}
